#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <stdbool.h>
#include "job_queue.h"

int job_queue_init(struct job_queue *job_queue, int capacity) {
  job_queue -> capacity = capacity; 
  job_queue -> count = 0; 
  job_queue -> isDestroyed = false; 
  assert(pthread_cond_init(&job_queue -> fillQ, NULL) == 0);
  assert(pthread_cond_init(&job_queue -> emptyQ, NULL) == 0);
  assert(pthread_mutex_init(&job_queue -> mut, NULL) == 0);
  return 0;
}

int job_queue_destroy(struct job_queue *job_queue) {
	if (job_queue != NULL) {
		pthread_mutex_lock(&job_queue -> mut);
		while (job_queue -> count != 0) {
			pthread_cond_wait(&job_queue -> emptyQ, &job_queue -> mut);
		}
		job_queue -> isDestroyed = true;
		pthread_cond_broadcast(&job_queue -> fillQ);
    	pthread_mutex_unlock(&job_queue -> mut);
		return 0;
	}
	return -1;
}

int job_queue_push(struct job_queue *job_queue, void *data) {
  	if (job_queue != NULL) {
  		pthread_mutex_lock(&job_queue -> mut);
		while (job_queue -> count + 1 > job_queue -> capacity) {
			pthread_cond_wait(&job_queue -> emptyQ, &job_queue -> mut);
		}
		struct job *newJob = malloc(sizeof(struct job));
		newJob -> next = job_queue -> head;
		newJob -> data = data;
		job_queue -> head = newJob;
		job_queue -> count++;
		
		pthread_cond_signal(&job_queue -> fillQ);
		pthread_mutex_unlock(&job_queue -> mut);
		return 0;

	}
	return 1;
}

int job_queue_pop(struct job_queue *job_queue, void **data) {
	if (job_queue != NULL) {
  		pthread_mutex_lock(&job_queue -> mut);
		while (job_queue -> count <= 0) {
			if (job_queue -> isDestroyed) {
				pthread_mutex_unlock(&job_queue -> mut);
				return -1;
			}
			assert(pthread_cond_wait(&job_queue -> fillQ, &job_queue -> mut) == 0);
		}
		*data = job_queue -> head -> data;
		struct job *currHead = job_queue -> head;
		job_queue -> head = job_queue -> head -> next;
		if (job_queue -> count != 0) {
			job_queue -> count--;
		}
		free(currHead);
		pthread_cond_signal(&job_queue -> emptyQ);
		pthread_mutex_unlock(&job_queue -> mut);
		return 0;
	}
	return 1;
}